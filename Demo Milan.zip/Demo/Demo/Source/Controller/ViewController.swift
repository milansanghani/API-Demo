//
//  ViewController.swift
//  Demo
//
//  Created by Mil$ Patel on 06/07/2019.
//  Copyright © 2019 TheProgrammer. All rights reserved.
//

import UIKit
import ObjectMapper

class ViewController: UIViewController {

    @IBOutlet weak var tableInsta: UITableView!
    
    // variable
    var arrHomeData = [Home]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // SetupUI
        setupUI()
        
        // Call API
        callWebService()
    }
}

extension ViewController {
    
    //Mark :- SetupUI
    func setupUI() {
        self.navigationItem.title = "INSTAGRAM"
        tableInsta.register(UINib(nibName: "InstaTableViewCell", bundle: nil), forCellReuseIdentifier: "InstaTableViewCell")
    }
    
    func callWebService() {
        
        APICalling().getHomeResponse() { (response, error) -> () in
            if let err = error
            {
                print(err)
            } else {
                print(response as Any)
                if let responseObject = response as? [[String : AnyObject]] {
                    let Drower = ObjectMapper.Mapper<Home>().mapArray(JSONArray: responseObject)
                    print(Drower)
                    self.arrHomeData = Drower
                    self.tableInsta.reloadData()
                } else{
                    print(error ?? "")
                }
            }
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrHomeData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "InstaTableViewCell", for: indexPath) as? InstaTableViewCell else {
            return UITableViewCell()
        }
        cell.fillTableCell(arrHomeData[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
