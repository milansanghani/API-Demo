//
//  InstaTableViewCell.swift
//  Demo
//
//  Created by Mil$ Patel on 06/07/2019.
//  Copyright © 2019 TheProgrammer. All rights reserved.
//

import UIKit
import SDWebImage

class InstaTableViewCell: UITableViewCell {

    @IBOutlet weak var imgUserProfile: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblNotes: UILabel!
    @IBOutlet weak var CollectionImages: UICollectionView!
    @IBOutlet weak var collectionHeight: NSLayoutConstraint!
    
    var arrImages = [Profile_images]()
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // setUp CollectionView
        setupCollection()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

extension InstaTableViewCell {
    func setupCollection() {
        CollectionImages.register(UINib(nibName: "ImagesCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ImagesCollectionViewCell")
        CollectionImages.delegate = self
        CollectionImages.dataSource = self
    }
    
    func fillTableCell(_ arrData: Home) {
        lblUserName.text = arrData.name
        lblNotes.text = arrData.note
        arrImages = arrData.profile_image ?? []
        CollectionImages.reloadData()
    }
}

extension InstaTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImagesCollectionViewCell", for: indexPath) as? ImagesCollectionViewCell else {
            return UICollectionViewCell()
        }
        cell.imgMedia.sd_imageIndicator = SDWebImageActivityIndicator.gray
        cell.imgMedia.sd_setImage(with: URL(string: arrImages[indexPath.row].media_url ?? ""))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.size.width, height: collectionView.bounds.size.height)
    }
}
