//
//  ImagesCollectionViewCell.swift
//  Demo
//
//  Created by Mil$ Patel on 06/07/2019.
//  Copyright © 2019 TheProgrammer. All rights reserved.
//

import UIKit

class ImagesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgMedia: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
