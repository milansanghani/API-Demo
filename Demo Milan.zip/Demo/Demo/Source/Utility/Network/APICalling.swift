import UIKit
import Foundation
import Alamofire

class APICalling: NSObject, HTTPProtocol {
    
    func getHomeResponse(completion: @escaping (_ response:AnyObject?, _ error: NSError?) -> ()) ->Void {
        executeWebService(method: .get , URLString: WebAPI.BaseUrl, parameters: nil, encoding: URLEncoding.default, headers: nil, completion: completion)
    }
}

