import UIKit

struct WebAPI {

    static let BaseUrl: String =  "http://www.mocky.io/v2/5cd2a23731000086283398ad"
}
