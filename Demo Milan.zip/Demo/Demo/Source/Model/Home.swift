//
//  ViewController.swift
//  Demo
//
//  Created by Mil$ Patel on 06/07/2019.
//  Copyright © 2019 TheProgrammer. All rights reserved.
//

import UIKit
import ObjectMapper

class Home: NSObject, Mappable {
    
    var id : String?
    var name : String?
    var note : String?
    var age : String?
    var profile_image : [Profile_images]?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        id <- map["id"]
        name <- map["name"]
        note <- map["note"]
        age <- map["age"]
        profile_image <- map["profile_image"]
        if profile_image == nil
        {
            profile_image <- map["profile_images"]
        }
    }
}

class Profile_images: NSObject, Mappable {
    
    var media_type : Int?
    var media_url : String?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        
        media_type <- map["media_type"]
        media_url <- map["media_url"]
    }
    
}
